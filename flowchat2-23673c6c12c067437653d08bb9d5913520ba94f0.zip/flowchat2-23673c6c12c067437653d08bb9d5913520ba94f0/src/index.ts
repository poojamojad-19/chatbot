export type { BotProps } from './components/Bot'
export type { BubbleProps } from './features/bubble/components/Bubble'
