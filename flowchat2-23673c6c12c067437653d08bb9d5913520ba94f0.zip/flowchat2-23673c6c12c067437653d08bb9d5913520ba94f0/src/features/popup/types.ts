export type PopupParams = {
  autoShowDelay?: number
  theme?: {
    width?: string
    backgroundColor?: string
  }
}
